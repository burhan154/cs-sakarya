﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yemek
{
    public partial class Ogrenci : Form
    {
        Baglanti baglanti = new Baglanti();
        int guncel_no;
        int a = 10;
        int b = 0;
        int Move;
        int Mouse_X;
        int Mouse_Y;
        public Ogrenci(string text)
        {
            DoubleBuffered = true;
            InitializeComponent();
            baglanti.kisiNo = text;
        }
        private void Ogrenci_Load(object sender, EventArgs e)
        {
            if (baglanti.oAdi())
            {
                baglanti.ogrKart();
                oAdi.Text = baglanti.kisiAdi;
                lbAd.Text = baglanti.kisiAdi;
                lbBakiye.Text = baglanti.ogrBakiye+"";
                kartNo.Text = baglanti.ogrKartNo+"";
                sonAktif.Text = baglanti.ogrSonAktif;
                if (baglanti.ogrDurum)
                {
                    kartDurum.Text = "Kart Aktif";
                }
                else
                {
                    kartDurum.Text = "Kart İnaktif";
                }
                dataGridView1.DataSource = baglanti.ogrGecmis();
                dataGridView1.RowHeadersVisible = false;
                dataGridView1.Columns[0].Width = 140;
                dataGridView1.Columns[1].Width = 160;
                dataGridView1.Columns[2].Width = 160;
                dataGridView1.Columns[3].Width = 160;
            }
            else
            {
                MessageBox.Show("Bağlantı hatası oluştu lütfen daha sonra tekrar deneyiniz.");
                Close();
            }
        }
        private void pnlUst_MouseDown(object sender, MouseEventArgs e)
        {
            Move = 1;
            Mouse_X = e.X;
            Mouse_Y = e.Y;
        }
        private void pnlUst_MouseMove(object sender, MouseEventArgs e)
        {
            if (Move == 1)
            {
                this.SetDesktopLocation(MousePosition.X - Mouse_X, MousePosition.Y - Mouse_Y);
            }
        }
        private void pnlUst_MouseUp(object sender, MouseEventArgs e)
        {
            Move = 0;
        }
        private void sifreDegistir_Click(object sender, EventArgs e)
        {
            if (sifre2.Text == sifre3.Text)
            {
                if (baglanti.psifreDegistir(sifre1.Text, sifre2.Text))
                {
                    MessageBox.Show("Sifre başarıyla değiştirildi.");
                    sifre1.Text = "";
                    sifre2.Text = "";
                    sifre3.Text = "";
                }
                else
                {
                    MessageBox.Show("Eski şifrenizi kontrol ediniz.");
                }
            }
            else
            {
                MessageBox.Show("Yeni şifreler aynı değil.");
            }
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
             Close(); Environment.Exit(1);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (b == 0)
            {
                a = a + 5;
                if (a == 380)
                {
                    b = 1;
                    timer1.Enabled = false;
                }
            }
            else if (b == 1)
            {
                a = a - 5;
                if (a == 10)
                {
                    b = 0;
                    timer1.Enabled = false;
                }
            }
            panel1.Size = new System.Drawing.Size(657, a);
        }
        private void btnMenu_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void sifreDegistir_Click_1(object sender, EventArgs e)
        {
            if (sifre2.Text == sifre3.Text)
            {
                if (baglanti.osifreDegistir(sifre1.Text, sifre2.Text))
                {
                    MessageBox.Show("Sifre başarıyla değiştirildi.");
                    sifre1.Text = "";
                    sifre2.Text = "";
                    sifre3.Text = "";
                }
                else
                {
                    MessageBox.Show("Eski şifrenizi kontrol ediniz.");
                }
            }
            else
            {
                MessageBox.Show("Yeni şifreler aynı değil.");
            }
        }
    }
}
