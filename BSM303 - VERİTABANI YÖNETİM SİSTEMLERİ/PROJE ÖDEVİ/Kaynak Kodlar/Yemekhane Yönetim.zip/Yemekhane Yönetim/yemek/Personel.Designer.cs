﻿namespace yemek
{
    partial class Personel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtOgr = new System.Windows.Forms.TextBox();
            this.lblNo = new System.Windows.Forms.Label();
            this.btnOgr = new System.Windows.Forms.Button();
            this.lbAd = new System.Windows.Forms.Label();
            this.pnlPersonel = new System.Windows.Forms.Panel();
            this.pnlBakiye = new System.Windows.Forms.Panel();
            this.para1 = new System.Windows.Forms.Button();
            this.btnPara = new System.Windows.Forms.Button();
            this.para2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.para4 = new System.Windows.Forms.Button();
            this.txtPara = new System.Windows.Forms.TextBox();
            this.para5 = new System.Windows.Forms.Button();
            this.para6 = new System.Windows.Forms.Button();
            this.para3 = new System.Windows.Forms.Button();
            this.tbno = new System.Windows.Forms.Label();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.pnlUst = new System.Windows.Forms.Panel();
            this.pAdi = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.sifre3 = new System.Windows.Forms.TextBox();
            this.sifre2 = new System.Windows.Forms.TextBox();
            this.sifreDegistir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.sifre1 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbBakiye = new System.Windows.Forms.Label();
            this.pnlPersonel.SuspendLayout();
            this.pnlBakiye.SuspendLayout();
            this.pnlUst.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtOgr
            // 
            this.txtOgr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtOgr.Location = new System.Drawing.Point(28, 67);
            this.txtOgr.MaxLength = 10;
            this.txtOgr.Name = "txtOgr";
            this.txtOgr.Size = new System.Drawing.Size(156, 22);
            this.txtOgr.TabIndex = 34;
            // 
            // lblNo
            // 
            this.lblNo.AutoSize = true;
            this.lblNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNo.ForeColor = System.Drawing.Color.White;
            this.lblNo.Location = new System.Drawing.Point(25, 44);
            this.lblNo.Name = "lblNo";
            this.lblNo.Size = new System.Drawing.Size(131, 16);
            this.lblNo.TabIndex = 32;
            this.lblNo.Text = "KART NUMARASI";
            // 
            // btnOgr
            // 
            this.btnOgr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnOgr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOgr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgr.ForeColor = System.Drawing.Color.White;
            this.btnOgr.Location = new System.Drawing.Point(28, 95);
            this.btnOgr.Name = "btnOgr";
            this.btnOgr.Size = new System.Drawing.Size(156, 32);
            this.btnOgr.TabIndex = 28;
            this.btnOgr.Text = "GİRİŞ";
            this.btnOgr.UseVisualStyleBackColor = false;
            this.btnOgr.Click += new System.EventHandler(this.btnOgr_Click);
            // 
            // lbAd
            // 
            this.lbAd.AutoSize = true;
            this.lbAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbAd.ForeColor = System.Drawing.Color.White;
            this.lbAd.Location = new System.Drawing.Point(12, 52);
            this.lbAd.Name = "lbAd";
            this.lbAd.Size = new System.Drawing.Size(173, 33);
            this.lbAd.TabIndex = 41;
            this.lbAd.Text = "AD SOYAD";
            // 
            // pnlPersonel
            // 
            this.pnlPersonel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPersonel.Controls.Add(this.pnlBakiye);
            this.pnlPersonel.Controls.Add(this.btnOgr);
            this.pnlPersonel.Controls.Add(this.lblNo);
            this.pnlPersonel.Controls.Add(this.txtOgr);
            this.pnlPersonel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlPersonel.Location = new System.Drawing.Point(0, 101);
            this.pnlPersonel.Name = "pnlPersonel";
            this.pnlPersonel.Size = new System.Drawing.Size(657, 282);
            this.pnlPersonel.TabIndex = 51;
            // 
            // pnlBakiye
            // 
            this.pnlBakiye.Controls.Add(this.para1);
            this.pnlBakiye.Controls.Add(this.btnPara);
            this.pnlBakiye.Controls.Add(this.para2);
            this.pnlBakiye.Controls.Add(this.label3);
            this.pnlBakiye.Controls.Add(this.para4);
            this.pnlBakiye.Controls.Add(this.txtPara);
            this.pnlBakiye.Controls.Add(this.para5);
            this.pnlBakiye.Controls.Add(this.para6);
            this.pnlBakiye.Controls.Add(this.para3);
            this.pnlBakiye.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlBakiye.Enabled = false;
            this.pnlBakiye.Location = new System.Drawing.Point(204, 0);
            this.pnlBakiye.Name = "pnlBakiye";
            this.pnlBakiye.Size = new System.Drawing.Size(451, 280);
            this.pnlBakiye.TabIndex = 52;
            // 
            // para1
            // 
            this.para1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.para1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.para1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.para1.ForeColor = System.Drawing.Color.White;
            this.para1.Location = new System.Drawing.Point(22, 18);
            this.para1.Name = "para1";
            this.para1.Size = new System.Drawing.Size(131, 64);
            this.para1.TabIndex = 43;
            this.para1.Text = "5 TL";
            this.para1.UseVisualStyleBackColor = false;
            this.para1.Click += new System.EventHandler(this.para1_Click);
            // 
            // btnPara
            // 
            this.btnPara.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnPara.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPara.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnPara.ForeColor = System.Drawing.Color.White;
            this.btnPara.Location = new System.Drawing.Point(184, 185);
            this.btnPara.Name = "btnPara";
            this.btnPara.Size = new System.Drawing.Size(156, 32);
            this.btnPara.TabIndex = 49;
            this.btnPara.Text = "0 TL";
            this.btnPara.UseVisualStyleBackColor = false;
            this.btnPara.Click += new System.EventHandler(this.btnPara_Click);
            // 
            // para2
            // 
            this.para2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.para2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.para2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.para2.ForeColor = System.Drawing.Color.White;
            this.para2.Location = new System.Drawing.Point(159, 18);
            this.para2.Name = "para2";
            this.para2.Size = new System.Drawing.Size(131, 64);
            this.para2.TabIndex = 44;
            this.para2.Text = "10 TL";
            this.para2.UseVisualStyleBackColor = false;
            this.para2.Click += new System.EventHandler(this.para2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(19, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 16);
            this.label3.TabIndex = 50;
            this.label3.Text = "MİKTAR";
            // 
            // para4
            // 
            this.para4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.para4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.para4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.para4.ForeColor = System.Drawing.Color.White;
            this.para4.Location = new System.Drawing.Point(22, 88);
            this.para4.Name = "para4";
            this.para4.Size = new System.Drawing.Size(131, 64);
            this.para4.TabIndex = 45;
            this.para4.Text = "30 TL";
            this.para4.UseVisualStyleBackColor = false;
            this.para4.Click += new System.EventHandler(this.para4_Click);
            // 
            // txtPara
            // 
            this.txtPara.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtPara.Location = new System.Drawing.Point(22, 190);
            this.txtPara.MaxLength = 3;
            this.txtPara.Name = "txtPara";
            this.txtPara.Size = new System.Drawing.Size(156, 22);
            this.txtPara.TabIndex = 51;
            this.txtPara.Text = "0";
            this.txtPara.TextChanged += new System.EventHandler(this.txtpara_TextChanged);
            // 
            // para5
            // 
            this.para5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.para5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.para5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.para5.ForeColor = System.Drawing.Color.White;
            this.para5.Location = new System.Drawing.Point(159, 88);
            this.para5.Name = "para5";
            this.para5.Size = new System.Drawing.Size(131, 64);
            this.para5.TabIndex = 46;
            this.para5.Text = "50 TL";
            this.para5.UseVisualStyleBackColor = false;
            this.para5.Click += new System.EventHandler(this.para5_Click);
            // 
            // para6
            // 
            this.para6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.para6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.para6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.para6.ForeColor = System.Drawing.Color.White;
            this.para6.Location = new System.Drawing.Point(296, 88);
            this.para6.Name = "para6";
            this.para6.Size = new System.Drawing.Size(131, 64);
            this.para6.TabIndex = 48;
            this.para6.Text = "100 TL";
            this.para6.UseVisualStyleBackColor = false;
            this.para6.Click += new System.EventHandler(this.para6_Click);
            // 
            // para3
            // 
            this.para3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.para3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.para3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.para3.ForeColor = System.Drawing.Color.White;
            this.para3.Location = new System.Drawing.Point(296, 18);
            this.para3.Name = "para3";
            this.para3.Size = new System.Drawing.Size(131, 64);
            this.para3.TabIndex = 47;
            this.para3.Text = "20 TL";
            this.para3.UseVisualStyleBackColor = false;
            this.para3.Click += new System.EventHandler(this.para3_Click);
            // 
            // tbno
            // 
            this.tbno.AutoSize = true;
            this.tbno.Location = new System.Drawing.Point(-6, 8);
            this.tbno.Name = "tbno";
            this.tbno.Size = new System.Drawing.Size(0, 13);
            this.tbno.TabIndex = 48;
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnMenu.BackgroundImage = global::yemek.Properties.Resources.menu_icon;
            this.btnMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnMenu.Location = new System.Drawing.Point(0, 0);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(53, 31);
            this.btnMenu.TabIndex = 42;
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(16)))), ((int)(((byte)(23)))));
            this.btnCikis.BackgroundImage = global::yemek.Properties.Resources.exit;
            this.btnCikis.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCikis.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCikis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCikis.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnCikis.Location = new System.Drawing.Point(604, 0);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(53, 31);
            this.btnCikis.TabIndex = 43;
            this.btnCikis.UseVisualStyleBackColor = false;
            this.btnCikis.Click += new System.EventHandler(this.kapat_Click);
            // 
            // pnlUst
            // 
            this.pnlUst.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.pnlUst.Controls.Add(this.pAdi);
            this.pnlUst.Controls.Add(this.title);
            this.pnlUst.Controls.Add(this.btnCikis);
            this.pnlUst.Controls.Add(this.btnMenu);
            this.pnlUst.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlUst.Location = new System.Drawing.Point(0, 0);
            this.pnlUst.Name = "pnlUst";
            this.pnlUst.Size = new System.Drawing.Size(657, 31);
            this.pnlUst.TabIndex = 49;
            this.pnlUst.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlUst_MouseDown);
            this.pnlUst.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlUst_MouseMove);
            this.pnlUst.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlUst_MouseUp);
            // 
            // pAdi
            // 
            this.pAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pAdi.ForeColor = System.Drawing.Color.White;
            this.pAdi.Location = new System.Drawing.Point(425, 7);
            this.pAdi.Name = "pAdi";
            this.pAdi.Size = new System.Drawing.Size(173, 16);
            this.pAdi.TabIndex = 54;
            this.pAdi.Text = "PERSONEL ADI";
            this.pAdi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.title.ForeColor = System.Drawing.Color.White;
            this.title.Location = new System.Drawing.Point(59, 7);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(187, 16);
            this.title.TabIndex = 42;
            this.title.Text = "PARA YÜKLEME SİSTEMİ";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.sifre3);
            this.panel1.Controls.Add(this.sifre2);
            this.panel1.Controls.Add(this.sifreDegistir);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.sifre1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 383);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(657, 10);
            this.panel1.TabIndex = 52;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(198, 150);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 16);
            this.label5.TabIndex = 38;
            this.label5.Text = "TEKRAR YENİ ŞİFRE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(201, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 16);
            this.label4.TabIndex = 37;
            this.label4.Text = "YENİ ŞİFRE";
            // 
            // sifre3
            // 
            this.sifre3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifre3.Location = new System.Drawing.Point(201, 170);
            this.sifre3.MaxLength = 10;
            this.sifre3.Name = "sifre3";
            this.sifre3.Size = new System.Drawing.Size(251, 22);
            this.sifre3.TabIndex = 36;
            this.sifre3.UseSystemPasswordChar = true;
            // 
            // sifre2
            // 
            this.sifre2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifre2.Location = new System.Drawing.Point(201, 111);
            this.sifre2.MaxLength = 10;
            this.sifre2.Name = "sifre2";
            this.sifre2.Size = new System.Drawing.Size(251, 22);
            this.sifre2.TabIndex = 35;
            this.sifre2.UseSystemPasswordChar = true;
            // 
            // sifreDegistir
            // 
            this.sifreDegistir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.sifreDegistir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sifreDegistir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifreDegistir.ForeColor = System.Drawing.Color.White;
            this.sifreDegistir.Location = new System.Drawing.Point(201, 211);
            this.sifreDegistir.Name = "sifreDegistir";
            this.sifreDegistir.Size = new System.Drawing.Size(251, 32);
            this.sifreDegistir.TabIndex = 28;
            this.sifreDegistir.Text = "ŞİFRE DEĞİŞTİR";
            this.sifreDegistir.UseVisualStyleBackColor = false;
            this.sifreDegistir.Click += new System.EventHandler(this.sifreDegistir_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(198, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 16);
            this.label2.TabIndex = 32;
            this.label2.Text = "ESKİ ŞİFRE";
            // 
            // sifre1
            // 
            this.sifre1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifre1.Location = new System.Drawing.Point(201, 54);
            this.sifre1.MaxLength = 10;
            this.sifre1.Name = "sifre1";
            this.sifre1.Size = new System.Drawing.Size(251, 22);
            this.sifre1.TabIndex = 34;
            this.sifre1.UseSystemPasswordChar = true;
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbBakiye
            // 
            this.lbBakiye.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbBakiye.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbBakiye.ForeColor = System.Drawing.Color.White;
            this.lbBakiye.Location = new System.Drawing.Point(428, 52);
            this.lbBakiye.Name = "lbBakiye";
            this.lbBakiye.Size = new System.Drawing.Size(211, 33);
            this.lbBakiye.TabIndex = 53;
            this.lbBakiye.Text = "BAKİYE";
            this.lbBakiye.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Personel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(101)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(657, 393);
            this.Controls.Add(this.pnlUst);
            this.Controls.Add(this.pnlPersonel);
            this.Controls.Add(this.lbBakiye);
            this.Controls.Add(this.tbno);
            this.Controls.Add(this.lbAd);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Personel";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Personel";
            this.Load += new System.EventHandler(this.Personel_Load);
            this.pnlPersonel.ResumeLayout(false);
            this.pnlPersonel.PerformLayout();
            this.pnlBakiye.ResumeLayout(false);
            this.pnlBakiye.PerformLayout();
            this.pnlUst.ResumeLayout(false);
            this.pnlUst.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtOgr;
        private System.Windows.Forms.Label lblNo;
        private System.Windows.Forms.Button btnOgr;
        private System.Windows.Forms.Label lbAd;
        private System.Windows.Forms.Panel pnlPersonel;
        private System.Windows.Forms.Label tbno;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Panel pnlUst;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Button para5;
        private System.Windows.Forms.Button para4;
        private System.Windows.Forms.Button para2;
        private System.Windows.Forms.Button para1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button sifreDegistir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox sifre1;
        private System.Windows.Forms.TextBox sifre3;
        private System.Windows.Forms.TextBox sifre2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnPara;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPara;
        private System.Windows.Forms.Button para6;
        private System.Windows.Forms.Button para3;
        private System.Windows.Forms.Label lbBakiye;
        private System.Windows.Forms.Panel pnlBakiye;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label pAdi;
    }
}