﻿namespace yemek
{
    partial class Ogrenci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lbBakiye = new System.Windows.Forms.Label();
            this.sifreDegistir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.sifre1 = new System.Windows.Forms.TextBox();
            this.pnlPersonel = new System.Windows.Forms.Panel();
            this.kartDurum = new System.Windows.Forms.Label();
            this.sonAktif = new System.Windows.Forms.Label();
            this.kartNo = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.sifre3 = new System.Windows.Forms.TextBox();
            this.sifre2 = new System.Windows.Forms.TextBox();
            this.oAdi = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.Label();
            this.pnlUst = new System.Windows.Forms.Panel();
            this.btnCikis = new System.Windows.Forms.Button();
            this.btnMenu = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tbno = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbAd = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnlPersonel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.pnlUst.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbBakiye
            // 
            this.lbBakiye.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbBakiye.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbBakiye.ForeColor = System.Drawing.Color.White;
            this.lbBakiye.Location = new System.Drawing.Point(500, 52);
            this.lbBakiye.Name = "lbBakiye";
            this.lbBakiye.Size = new System.Drawing.Size(142, 33);
            this.lbBakiye.TabIndex = 59;
            this.lbBakiye.Text = "BAKİYE";
            this.lbBakiye.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // sifreDegistir
            // 
            this.sifreDegistir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.sifreDegistir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sifreDegistir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifreDegistir.ForeColor = System.Drawing.Color.White;
            this.sifreDegistir.Location = new System.Drawing.Point(201, 242);
            this.sifreDegistir.Name = "sifreDegistir";
            this.sifreDegistir.Size = new System.Drawing.Size(251, 32);
            this.sifreDegistir.TabIndex = 28;
            this.sifreDegistir.Text = "ŞİFRE DEĞİŞTİR";
            this.sifreDegistir.UseVisualStyleBackColor = false;
            this.sifreDegistir.Click += new System.EventHandler(this.sifreDegistir_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(198, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 16);
            this.label2.TabIndex = 32;
            this.label2.Text = "ESKİ ŞİFRE";
            // 
            // sifre1
            // 
            this.sifre1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifre1.Location = new System.Drawing.Point(201, 85);
            this.sifre1.MaxLength = 10;
            this.sifre1.Name = "sifre1";
            this.sifre1.Size = new System.Drawing.Size(251, 22);
            this.sifre1.TabIndex = 34;
            this.sifre1.UseSystemPasswordChar = true;
            // 
            // pnlPersonel
            // 
            this.pnlPersonel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPersonel.Controls.Add(this.kartDurum);
            this.pnlPersonel.Controls.Add(this.sonAktif);
            this.pnlPersonel.Controls.Add(this.kartNo);
            this.pnlPersonel.Controls.Add(this.dataGridView1);
            this.pnlPersonel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlPersonel.Location = new System.Drawing.Point(0, 108);
            this.pnlPersonel.Name = "pnlPersonel";
            this.pnlPersonel.Size = new System.Drawing.Size(650, 282);
            this.pnlPersonel.TabIndex = 57;
            // 
            // kartDurum
            // 
            this.kartDurum.AutoSize = true;
            this.kartDurum.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kartDurum.ForeColor = System.Drawing.Color.White;
            this.kartDurum.Location = new System.Drawing.Point(273, 8);
            this.kartDurum.Name = "kartDurum";
            this.kartDurum.Size = new System.Drawing.Size(120, 25);
            this.kartDurum.TabIndex = 61;
            this.kartDurum.Text = "kartDurum";
            // 
            // sonAktif
            // 
            this.sonAktif.AutoSize = true;
            this.sonAktif.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sonAktif.ForeColor = System.Drawing.Color.White;
            this.sonAktif.Location = new System.Drawing.Point(512, 8);
            this.sonAktif.Name = "sonAktif";
            this.sonAktif.Size = new System.Drawing.Size(97, 25);
            this.sonAktif.TabIndex = 61;
            this.sonAktif.Text = "sonAktif";
            // 
            // kartNo
            // 
            this.kartNo.AutoSize = true;
            this.kartNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kartNo.ForeColor = System.Drawing.Color.White;
            this.kartNo.Location = new System.Drawing.Point(15, 8);
            this.kartNo.Name = "kartNo";
            this.kartNo.Size = new System.Drawing.Size(81, 25);
            this.kartNo.TabIndex = 60;
            this.kartNo.Text = "kartNo";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView1.Location = new System.Drawing.Point(3, 36);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(642, 239);
            this.dataGridView1.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(198, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 16);
            this.label5.TabIndex = 38;
            this.label5.Text = "TEKRAR YENİ ŞİFRE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(201, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 16);
            this.label4.TabIndex = 37;
            this.label4.Text = "YENİ ŞİFRE";
            // 
            // sifre3
            // 
            this.sifre3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifre3.Location = new System.Drawing.Point(201, 201);
            this.sifre3.MaxLength = 10;
            this.sifre3.Name = "sifre3";
            this.sifre3.Size = new System.Drawing.Size(251, 22);
            this.sifre3.TabIndex = 36;
            this.sifre3.UseSystemPasswordChar = true;
            // 
            // sifre2
            // 
            this.sifre2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.sifre2.Location = new System.Drawing.Point(201, 142);
            this.sifre2.MaxLength = 10;
            this.sifre2.Name = "sifre2";
            this.sifre2.Size = new System.Drawing.Size(251, 22);
            this.sifre2.TabIndex = 35;
            this.sifre2.UseSystemPasswordChar = true;
            // 
            // oAdi
            // 
            this.oAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.oAdi.ForeColor = System.Drawing.Color.White;
            this.oAdi.Location = new System.Drawing.Point(425, 7);
            this.oAdi.Name = "oAdi";
            this.oAdi.Size = new System.Drawing.Size(173, 16);
            this.oAdi.TabIndex = 54;
            this.oAdi.Text = "OGRENCİ ADI";
            this.oAdi.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.title.ForeColor = System.Drawing.Color.White;
            this.title.Location = new System.Drawing.Point(59, 7);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(181, 16);
            this.title.TabIndex = 42;
            this.title.Text = "ÖĞRENCİ BİLGİ SİSTEMİ";
            // 
            // pnlUst
            // 
            this.pnlUst.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.pnlUst.Controls.Add(this.oAdi);
            this.pnlUst.Controls.Add(this.title);
            this.pnlUst.Controls.Add(this.btnCikis);
            this.pnlUst.Controls.Add(this.btnMenu);
            this.pnlUst.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlUst.Location = new System.Drawing.Point(0, 0);
            this.pnlUst.Name = "pnlUst";
            this.pnlUst.Size = new System.Drawing.Size(650, 31);
            this.pnlUst.TabIndex = 56;
            this.pnlUst.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlUst_MouseDown);
            this.pnlUst.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlUst_MouseMove);
            this.pnlUst.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlUst_MouseUp);
            // 
            // btnCikis
            // 
            this.btnCikis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(16)))), ((int)(((byte)(23)))));
            this.btnCikis.BackgroundImage = global::yemek.Properties.Resources.exit;
            this.btnCikis.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCikis.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCikis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCikis.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnCikis.Location = new System.Drawing.Point(597, 0);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(53, 31);
            this.btnCikis.TabIndex = 43;
            this.btnCikis.UseVisualStyleBackColor = false;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(175)))), ((int)(((byte)(80)))));
            this.btnMenu.BackgroundImage = global::yemek.Properties.Resources.menu_icon;
            this.btnMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnMenu.Location = new System.Drawing.Point(0, 0);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(53, 31);
            this.btnMenu.TabIndex = 42;
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tbno
            // 
            this.tbno.AutoSize = true;
            this.tbno.Location = new System.Drawing.Point(-3, 8);
            this.tbno.Name = "tbno";
            this.tbno.Size = new System.Drawing.Size(0, 13);
            this.tbno.TabIndex = 55;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.sifre3);
            this.panel1.Controls.Add(this.sifre2);
            this.panel1.Controls.Add(this.sifreDegistir);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.sifre1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 390);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(650, 10);
            this.panel1.TabIndex = 58;
            // 
            // lbAd
            // 
            this.lbAd.AutoSize = true;
            this.lbAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbAd.ForeColor = System.Drawing.Color.White;
            this.lbAd.Location = new System.Drawing.Point(15, 52);
            this.lbAd.Name = "lbAd";
            this.lbAd.Size = new System.Drawing.Size(173, 33);
            this.lbAd.TabIndex = 54;
            this.lbAd.Text = "AD SOYAD";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(573, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 16);
            this.label3.TabIndex = 61;
            this.label3.Text = "BAKİYE:";
            // 
            // Ogrenci
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(101)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(650, 400);
            this.Controls.Add(this.pnlUst);
            this.Controls.Add(this.pnlPersonel);
            this.Controls.Add(this.tbno);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbAd);
            this.Controls.Add(this.lbBakiye);
            this.Controls.Add(this.label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Ogrenci";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ogrenci";
            this.Load += new System.EventHandler(this.Ogrenci_Load);
            this.pnlPersonel.ResumeLayout(false);
            this.pnlPersonel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.pnlUst.ResumeLayout(false);
            this.pnlUst.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbBakiye;
        private System.Windows.Forms.Button sifreDegistir;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox sifre1;
        private System.Windows.Forms.Panel pnlPersonel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox sifre3;
        private System.Windows.Forms.TextBox sifre2;
        private System.Windows.Forms.Label oAdi;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Panel pnlUst;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label tbno;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbAd;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label kartDurum;
        private System.Windows.Forms.Label sonAktif;
        private System.Windows.Forms.Label kartNo;
        private System.Windows.Forms.Label label3;
    }
}