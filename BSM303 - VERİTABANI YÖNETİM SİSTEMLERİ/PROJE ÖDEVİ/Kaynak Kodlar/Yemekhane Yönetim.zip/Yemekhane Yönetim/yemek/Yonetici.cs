﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yemek
{
    public partial class Yonetici : Form
    {
        Baglanti baglanti = new Baglanti();
        int Move;
        int Mouse_X;
        int Mouse_Y;

        int panel = 0;

        int menu = 0;
        string siralamaTuru = "_kart_no";
        string araTuru = "_ogrenci_no";
        public Yonetici(string text)
        {
            DoubleBuffered = true;
            InitializeComponent();
            baglanti.kisiNo = text;
        }
        private void Yonetici_Load(object sender, EventArgs e)
        {
            cbAra.SelectedIndex = 0;
            cbSırala.SelectedIndex = 0;
            if (baglanti.yAdi())
            {
                yAdi.Text = baglanti.kisiAdi;
                listele();
            }
            else
            {
                MessageBox.Show("Bağlantı hatası oluştu lütfen daha sonra tekrar deneyiniz.");
                Close();
            }
        }
        private void pnlUst_MouseDown(object sender, MouseEventArgs e)
        {
            Move = 1;
            Mouse_X = e.X;
            Mouse_Y = e.Y;
        }
        private void pnlUst_MouseMove(object sender, MouseEventArgs e)
        {
            if (Move == 1)
            {
                this.SetDesktopLocation(MousePosition.X - Mouse_X, MousePosition.Y - Mouse_Y);
            }
        }
        private void pnlUst_MouseUp(object sender, MouseEventArgs e)
        {
            Move = 0;
        }
        private void cikis(object sender, EventArgs e)
        {
            Close(); Environment.Exit(1);
        }
        private void cbSırala_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbSırala.SelectedIndex == 0)
            {
                siralamaTuru = "_kart_no";
            }
            else if (cbSırala.SelectedIndex == 1)
            {
                siralamaTuru = "_ogrenci_no";
            }
            else if (cbSırala.SelectedIndex == 2)
            {
                siralamaTuru = "_ad";
            }
            else if (cbSırala.SelectedIndex == 3)
            {
                siralamaTuru = "_soyad";
            }
            else if (cbSırala.SelectedIndex == 4)
            {
                siralamaTuru = "_kart_durumu";
            }
            else if (cbSırala.SelectedIndex == 5)
            {
                siralamaTuru = "_son_aktif";
            }
            listele();
        }
        void listele()
        {
            dataGridView1.DataSource = baglanti.ogrenciler(araTuru, siralamaTuru,txtAra.Text);
            menu = 0;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.Columns[0].Width = 100;
            dataGridView1.Columns[1].Width = 130;
            dataGridView1.Columns[2].Width = 140;
            dataGridView1.Columns[3].Width = 140;
            dataGridView1.Columns[4].Width = 80;
            dataGridView1.Columns[5].Width = 70;
            dataGridView1.Columns[6].Width = 110;

            dataGridView1.Columns[0].HeaderText = "Kart No";
            dataGridView1.Columns[1].HeaderText = "Öğrenci No";
            dataGridView1.Columns[2].HeaderText = "Ad";
            dataGridView1.Columns[3].HeaderText = "Soyad";
            dataGridView1.Columns[4].HeaderText = "Bakiye";
            dataGridView1.Columns[5].HeaderText = "Durum";
            dataGridView1.Columns[6].HeaderText = "Son Aktif";

            dataGridView1.ReadOnly = true;
        }
        private void cbAra_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbAra.SelectedIndex == 0)
            {
                araTuru = "_ogrenci_no";
            }
            else if (cbAra.SelectedIndex == 1)
            {
                araTuru = "_ad";
            }
            else if (cbAra.SelectedIndex == 2)
            {
                araTuru = "_soyad";
            }
            listele();
        }
        private void txtAra_TextChanged(object sender, EventArgs e)
        {
            listele();
        }
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (menu == 0)
            {
                baglanti.ogrKartNo = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
                kartNo.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                adSoyad.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString() + " " + dataGridView1.CurrentRow.Cells[3].Value.ToString();
                menu = 1;
                dataGridView1.DataSource = baglanti.ogrGecmis();

                dataGridView1.Columns[0].Width = 190;
                dataGridView1.Columns[1].Width = 200;
                dataGridView1.Columns[2].Width = 180;
                dataGridView1.Columns[3].Width = 180;

                dataGridView1.Columns[0].HeaderText = "Öğün";
                dataGridView1.Columns[1].HeaderText = "Yemekhane";
                dataGridView1.Columns[2].HeaderText = "Tarih";
                dataGridView1.Columns[3].HeaderText = "Saat";
                dataGridView1.ReadOnly = true;
            }
            else if (menu == 1)
            {
                listele();
            }
        }
        public void panel_Kapat()
        {
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
        }
        private void row5_Click(object sender, EventArgs e)
        {
            panel_Kapat();
            panel1.Visible = true;
        }
        private void row1_Click(object sender, EventArgs e)
        {
            panel_Kapat();
            panel2.Visible = true;
        }
        private void row2_Click(object sender, EventArgs e)
        {
            panel_Kapat();
            panel3.Visible = true;
            ogunler();
        }
        private void row6_Click(object sender, EventArgs e)
        {
            panel_Kapat();
            panel4.Visible = true;
            yemekhaneler();
        }
        private void row7_Click(object sender, EventArgs e)
        {
            panel_Kapat();
            panel5.Visible = true;
        }
        private void row3_Click(object sender, EventArgs e)
        {
            panel_Kapat();
            panel6.Visible = true;
        }
        public void ogunler()
        {
            dataGridView2.DataSource= baglanti.ogun();
            dataGridView2.RowHeadersVisible = false;
            dataGridView2.ReadOnly = true;

            dataGridView2.Columns[0].Width = 110;
            dataGridView2.Columns[1].Width = 110;
            dataGridView2.Columns[2].Width = 190;
            dataGridView2.Columns[3].Width = 60;

            dataGridView2.Columns[0].HeaderText = "Başlama Saati";
            dataGridView2.Columns[1].HeaderText = "Bitiş Saati";
            dataGridView2.Columns[2].HeaderText = "Öğün";
            dataGridView2.Columns[3].HeaderText = "Ücret";
        }
        public void yemekhaneler()
        {
            dataGridView3.DataSource = baglanti.yemekhane();
            dataGridView3.RowHeadersVisible = false;
            dataGridView3.ReadOnly = true;

            dataGridView3.Columns[0].Width = 110;
            dataGridView3.Columns[1].Width = 240;
            dataGridView3.Columns[2].Width = 120;

            dataGridView3.Columns[0].HeaderText = "Yemekhane";
            dataGridView3.Columns[1].HeaderText = "Adres";
            dataGridView3.Columns[2].HeaderText = "Detaylar";
        }
        private void ogrEkle_Click(object sender, EventArgs e)
        {
            if (baglanti.ogrEkle(oNo.Text, oAd.Text, oSoyad.Text,oSifre.Text))
            {
                MessageBox.Show(oNo.Text+" numaralı öğrenci başarıyla eklendi.");
            }
            else
            {
                MessageBox.Show("Öğrenci eklenemedi.");
            }
            oNo.Text = "";
            oSifre.Text = "";
            oAd.Text = "";
            oSoyad.Text = "";
        }
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            bas.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            bit.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            ogun.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
            ucret.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (baglanti.ogunEkle( bas.Text, bit.Text, ogun.Text, ucret.Text))
            {
                MessageBox.Show(ogun.Text + " yemeği başarıyla eklendi.");
            }
            else
            {
                MessageBox.Show("Öğün eklenemedi.");
            }
            ogunler();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (baglanti.ogunGuncelle(bas.Text, bit.Text, ogun.Text, ucret.Text))
            {
                MessageBox.Show(ogun.Text + " yemeği başarıyla güncellendi.");
            }
            else
            {
                MessageBox.Show("Öğün güncellenemedi.");
            }
            ogunler();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (baglanti.ogunSil(ogun.Text))
            {
                MessageBox.Show(ogun.Text + " yemeği başarıyla silindi.");
            }
            else
            {
                MessageBox.Show("Öğün silinemedi.");
            }
            ogunler();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            if (baglanti.yemekhaneEkle(yemekhane.Text, adres.Text, detay.Text))
            {
                MessageBox.Show(yemekhane.Text + " başarıyla eklendi.");
            }
            else
            {
                MessageBox.Show("Yemekhane eklenemedi.");
            }
            yemekhaneler();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (baglanti.yemekhaneGuncelle(yemekhane.Text, adres.Text, detay.Text))
            {
                MessageBox.Show(yemekhane.Text + " başarıyla güncellendi.");
            }
            else
            {
                MessageBox.Show("Yemekhane güncellenemedi.");
            }
            yemekhaneler();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (baglanti.yemekhaneSil(yemekhane.Text))
            {
                MessageBox.Show(yemekhane.Text + " başarıyla silindi.");
            }
            else
            {
                MessageBox.Show("Yemekhane silinemedi.");
            }
            yemekhaneler();
        }
        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            yemekhane.Text = dataGridView3.CurrentRow.Cells[0].Value.ToString();
            adres.Text = dataGridView3.CurrentRow.Cells[1].Value.ToString();
            detay.Text = dataGridView3.CurrentRow.Cells[2].Value.ToString();
        }
        private void sifreDegistir_Click(object sender, EventArgs e)
        {
            if (sifre2.Text == sifre3.Text)
            {
                if (baglanti.ysifreDegistir(sifre1.Text, sifre2.Text))
                {
                    MessageBox.Show("Sifre başarıyla değiştirildi.");
                    sifre1.Text = "";
                    sifre2.Text = "";
                    sifre3.Text = "";
                }
                else
                {
                    MessageBox.Show("Eski şifrenizi kontrol ediniz.");
                }
            }
            else
            {
                MessageBox.Show("Yeni şifreler aynı değil.");
            }
        }
    }
}
