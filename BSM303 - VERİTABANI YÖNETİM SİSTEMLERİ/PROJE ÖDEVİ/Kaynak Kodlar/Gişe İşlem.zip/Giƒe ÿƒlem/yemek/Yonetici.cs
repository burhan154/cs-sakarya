﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yemek
{
    public partial class Yonetici : Form
    {
        Baglanti baglanti = new Baglanti();
        string yemekhane;
        int guncel_no;
        double guncel_bakiye;

        int Move;
        int Mouse_X;
        int Mouse_Y;

        int panel =0;
        public Yonetici()
        {
            InitializeComponent();

        }
        private void Yonetici_Load(object sender, EventArgs e)
        {
            yemekhaneSorgu();
            ogunSorgu();
            dataGridView1.DataSource = baglanti.yiyenListesi(yemekhane);
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.Columns[0].Width = 150;
            dataGridView1.Columns[1].Width = 175;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            guncel_no = Convert.ToInt32(txtOgr.Text);
            if (baglanti.ogrBilgi(guncel_no))
            {
                if (baglanti.ogrDurum)
                {
                    if (baglanti.ogr_yemek(guncel_no))
                    {
                        if (ucretKesimi(baglanti.ogun_ucret))
                        {
                            if (faturaSorgu())
                            {
                                if (baglanti.giseEkle(guncel_no, yemekhane))
                                {
                                    lbAd.Text = baglanti.ogrAd;
                                    lbBakiye.Text = guncel_bakiye + " TL";
                                    lbEskiBakiye.Text = baglanti.ogrBakiye + " TL";
                                    txtOgr.Text = "";
                                    label5.Text = "KALAN BAKİYE";

                                    timer1.Enabled = true;
                                }
                            }
                        }
                    }
                    else
                    {
                        txtOgr.Text = "";
                        lbAd.Text = "";
                        lbBakiye.Text = "";
                        lbEskiBakiye.Text = "";
                        label5.Text = "";
                        MessageBox.Show("Aynı öğünü ikinci kez yiyemezsiniz.");
                    }
                }
                else
                {
                    txtOgr.Text = "";
                    lbAd.Text = "";
                    lbBakiye.Text = "";
                    lbEskiBakiye.Text = "";
                    label5.Text = "";
                    MessageBox.Show("Ögrenci kartı inaktif.");
                }
            }
            else
            {
                txtOgr.Text = "";
                lbAd.Text = "";
                lbBakiye.Text = "";
                lbEskiBakiye.Text = "";
                label5.Text = "";
                MessageBox.Show("Kart bulunamadı.");
            }
        }
        public void yemekhaneSorgu()
        {
            if (baglanti.yemekhaneler())
            {
                comboBox1.Items.AddRange(baglanti.yemekhane.ToArray());
                //label1.Text = baglanti.adres;
                //label2.Text = baglanti.detay;
                comboBox1.SelectedIndex = 0;
                yemekhane = comboBox1.Text;
            }
            else
            {
                MessageBox.Show("BAĞLANTI HATASI!");
            }
        }
        public void ogunSorgu()
        {
            if (baglanti.ogunSorgu())
            {
                if (baglanti.ogun == null)
                {
                    label3.Text = "YEMEK SAAT ARALIGINDA DEĞİLSİNİZ.";
                    label4.Text = "";
                    button1.Enabled = false;
                    txtOgr.Enabled = false;
                }
                else
                {
                    label3.Text = baglanti.ogun+" YEMEĞİ";
                    label4.Text = baglanti.ogun_ucret + " TL";
                }
            }
            else
            {
                MessageBox.Show("BAĞLANTI HATASI!");
            }
        }
        public bool faturaSorgu()
        {
            if (baglanti.faturaEkle())
            {
                //label1.Text = baglanti.fatura_no.ToString();
                return true;
            }
            else
            {
                MessageBox.Show("FATURA OLUŞTURULAMADI!");
                return false;
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            yemekhane = comboBox1.Text;
            dataGridView1.DataSource = baglanti.yiyenListesi(yemekhane);
        }
        bool ucretKesimi(double miktar)
        {
            guncel_bakiye = baglanti.ogrBakiye - miktar;
            if (baglanti.ogrBakiye >= baglanti.ogun_ucret)
            {
                if (baglanti.ucretKesimi(guncel_no, (guncel_bakiye).ToString()))
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("Hata oluştu para kesilemedi..");
                    return false;
                }
                lbAd.Text = "";
                lbBakiye.Text = "";
                txtOgr.Text = "";
            }
            else
            {
                MessageBox.Show("Yetersiz bakiye!");
                return false;
            }
            
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            dataGridView1.DataSource = baglanti.yiyenListesi(yemekhane);
            lbAd.Text = "";
            lbBakiye.Text = "";
            lbEskiBakiye.Text = "";
            label5.Text = "";
            timer1.Enabled = false;
        }
        private void pnlUst_MouseDown(object sender, MouseEventArgs e)
        {
            Move = 1;
            Mouse_X = e.X;
            Mouse_Y = e.Y;
        }
        private void pnlUst_MouseMove(object sender, MouseEventArgs e)
        {
            if (Move == 1)
            {
                this.SetDesktopLocation(MousePosition.X - Mouse_X, MousePosition.Y - Mouse_Y);
            }
        }
        private void pnlUst_MouseUp(object sender, MouseEventArgs e)
        {
            Move = 0;
        }

        private void cikis(object sender, EventArgs e)
        {
            Close(); Environment.Exit(1);
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            if (panel==0)
            {
                this.Size = new System.Drawing.Size(600, 523);
                panel = 1;
            }
            else
            {
                this.Size = new System.Drawing.Size(252, 523);
                panel = 0;
            }
        }
    }
}
