﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yemek
{
    public partial class Personel : Form
    {
        Baglanti baglanti = new Baglanti();
        int guncel_no;
        int a = 10;
        int b = 0;
        int Move;
        int Mouse_X;
        int Mouse_Y;
        public Personel(string text)
        {
            DoubleBuffered = true;
            InitializeComponent();
            baglanti.kisiNo = text;
        }
        private void Personel_Load(object sender, EventArgs e)
        {
            if (baglanti.pAdi())
            {
                pAdi.Text = baglanti.kisiAdi;
            }
            else
            {
                MessageBox.Show("Bağlantı hatası oluştu lütfen daha sonra tekrar deneyiniz.");
                Close();
            }
        }
        private void kapat_Click(object sender, EventArgs e)
        {
            Close();  Environment.Exit(1);
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (b == 0) {
                a=a+5;
                if (a == 300){
                    b = 1;
                    timer1.Enabled = false;
                }
            }
            else if (b == 1){
                a=a-5;
                if (a == 10){
                    b = 0;
                    timer1.Enabled = false;
                }
            }      
            panel1.Size = new System.Drawing.Size(657, a);
        }
        private void btnMenu_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }
        private void txtpara_TextChanged(object sender, EventArgs e)
        {
            btnPara.Text = txtPara.Text + " TL";
        }
        private void btnOgr_Click(object sender, EventArgs e)
        {
            Ogrenci();
        }
        void Ogrenci()
        {
            guncel_no = Convert.ToInt32(txtOgr.Text);
            if (baglanti.ogrBilgi(guncel_no))
            {
                lbAd.Text = baglanti.ogrAd;
                lbBakiye.Text = baglanti.ogrBakiye + " TL";
                if (baglanti.ogrDurum)
                {
                    pnlBakiye.Enabled = true;
                }
                else
                {
                    pnlBakiye.Enabled = false;
                    MessageBox.Show("Ögrenci kartı inaktif.");
                }
            }
            else
            {
                lbAd.Text = "";
                lbBakiye.Text = "";
                pnlBakiye.Enabled = false;
                MessageBox.Show("Kart bulunamadı.");
            }
        }
        void paraYukleme(double miktar) 
        {
            miktar = miktar + baglanti.ogrBakiye;
            if (baglanti.bakiyeYukle(guncel_no, miktar.ToString()))
            {
                Ogrenci();
                MessageBox.Show(guncel_no + " nolu kartın güncel bakiyesi " + baglanti.ogrBakiye + " TL'dir.");
            }
            else
            {
                MessageBox.Show("Hata oluştu para yüklenemedi..");
            }
            lbAd.Text = "";
            lbBakiye.Text = "";
            txtOgr.Text = "";
            pnlBakiye.Enabled = false;
        }
        private void para1_Click(object sender, EventArgs e)
        {
            paraYukleme(5);
        }
        private void para2_Click(object sender, EventArgs e)
        {
            paraYukleme(10);
        }
        private void para3_Click(object sender, EventArgs e)
        {
            paraYukleme(20);
        }
        private void para4_Click(object sender, EventArgs e)
        {
            paraYukleme(30);
        }
        private void para5_Click(object sender, EventArgs e)
        {
            paraYukleme(50);
        }
        private void para6_Click(object sender, EventArgs e)
        {
            paraYukleme(100);
        }
        private void btnPara_Click(object sender, EventArgs e)
        {
            double para = Double.Parse(txtPara.Text.Replace(',', '.'), CultureInfo.InvariantCulture);
            paraYukleme(para);
            txtPara.Text = "0";
        }
        private void pnlUst_MouseDown(object sender, MouseEventArgs e)
        {
            Move = 1;
            Mouse_X = e.X;
            Mouse_Y = e.Y;
        }
        private void pnlUst_MouseMove(object sender, MouseEventArgs e)
        {
            if (Move == 1)
            {
                this.SetDesktopLocation(MousePosition.X - Mouse_X, MousePosition.Y - Mouse_Y);
            }
        }
        private void pnlUst_MouseUp(object sender, MouseEventArgs e)
        {
            Move = 0;
        }
        private void sifreDegistir_Click(object sender, EventArgs e)
        {
            if (sifre2.Text==sifre3.Text)
            {
                if (baglanti.psifreDegistir(sifre1.Text, sifre2.Text))
                {
                    MessageBox.Show("Sifre başarıyla değiştirildi.");
                    sifre1.Text = "";
                    sifre2.Text = "";
                    sifre3.Text = "";
                }
                else
                {
                    MessageBox.Show("Eski şifrenizi kontrol ediniz.");
                }
            }
            else
            {
                MessageBox.Show("Yeni şifreler aynı değil.");
            }
        }
    }
}
